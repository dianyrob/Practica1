export const USER = 'dianyrob@hotmail.com'
export const PASS = 'rodija10'
export const INVALID_USER = 'dianyrob@hotmail.com'
export const INVALID_PASS = 'rodija10'
export const EMPTY_CREDENTIALS_ERROR_MSG = 'Blank email and password.'
export const TASK_NAME = 'My Task ' + parseInt(Math.random() * 10000000)
export const TASK_NAME_EDITED='My New Task ' + parseInt(Math.random() * 10000000)
export const BASE_URL = 'https://todoist.com/'